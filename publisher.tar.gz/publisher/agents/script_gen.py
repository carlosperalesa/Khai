import sys
import os
import json
import re
from datetime import datetime

# Add root to pythonpath
sys.path.append(os.getcwd())

import requests
import yaml
from dotenv import load_dotenv

from modules.libs.utils import SystemChecker, retry
from modules.publisher.database import Database
from modules.libs.telegram_handler import TelegramHandler
from modules.libs.logger import setup_logger
from modules.llm_manager import LLMManager

logger = setup_logger("Agente3")

class Agente3ScriptHandler:
    def __init__(self, config):
        self.config = config
        self.db = Database(config['paths']['database'])
        
        load_dotenv()
        
        self.api_manager = LLMManager(
            config_dir="config",
            data_dir=os.path.join(config.get('paths', {}).get('data', 'data'), "llm")
        )
        
        self.telegram = TelegramHandler(
            bot_token=os.getenv("TELEGRAM_BOT_TOKEN"),
            user_id=os.getenv("TELEGRAM_USER_ID")
        )
        self.target_minutes = config['content']['video_duration_target_minutes']

    @retry(max_attempts=3, delay=3)
    def _generate_script(self, tema, keywords, extra_instructions=""):
        prompt = f"""
        TAREA: Generar un script para video de YouTube educativo.
        
        TEMA: {tema}
        PALABRAS CLAVE: {', '.join(keywords)}
        DURACIÓN OBJETIVO: {self.target_minutes} minutos (~{self.target_minutes * 150} palabras)
        IDIOMA: Español
        TONO: Educativo, interesante, directo
        AUDIENCIA: Personas interesadas en tecnología
        
        ESTRUCTURA REQUERIDA:
        1. Introducción gancho (50-70 palabras): Pregunta provocadora
        2. Problema/Contexto (200-300 palabras): Explica el tema actual
        3. Desarrollo parte 1 (300-400 palabras): Primer subtema
        4. Desarrollo parte 2 (300-400 palabras): Segundo subtema
        5. Implicaciones/Futuro (200-300 palabras): ¿Qué viene después?
        6. Conclusión/CTA (80-100 palabras): Resumen + call to action
        
        RESTRICCIONES:
        - Dividir en párrafos.
        - Lenguaje simple y accesible.
        - Ser específico con números/datos.
        {extra_instructions}
        
        FORMATO DE RESPUESTA EXIGIDO (Debes usar estas marcas exactas):
        [PÁRRAFO 1] ---contenido aquí--- [FIN PÁRRAFO 1]
        [PÁRRAFO 2] ---contenido aquí--- [FIN PÁRRAFO 2]
        
        Genera el script AHORA:
        """
        try:
            return self.api_manager.generate_content(prompt)
        except Exception as e:
            raise ValueError(f"Gemini API falló: {e}")

    def _parse_script(self, text):
        paragraphs = []
        pattern = r'\[PÁRRAFO \d+\](.*?)\[FIN PÁRRAFO \d+\]'
        matches = re.findall(pattern, text, re.DOTALL)
        
        for i, content in enumerate(matches, 1):
            clean_content = content.strip()
            palabras = len(clean_content.split())
            duracion_seg = palabras * 3  # ~3 seg por palabra
            
            paragraphs.append({
                "numero": i,
                "contenido": clean_content,
                "palabras": palabras,
                "duracion_segundos": duracion_seg
            })
            
        total_palabras = sum(p['palabras'] for p in paragraphs)
        total_duracion = sum(p['duracion_segundos'] for p in paragraphs)
        
        return {
            "parrafos": paragraphs,
            "total_palabras": total_palabras,
            "total_duracion_segundos": total_duracion,
            "total_duracion_formateado": f"{total_duracion // 60}:{total_duracion % 60:02d}"
        }

    def execute(self, response: str = None):
        try:
            SystemChecker.assert_resources()
            
            video = self.db.get_latest_video()
            if not video:
                raise ValueError("No hay videos en la BD.")
                
            estado_actual = video.get("estado_actual")
            
            if estado_actual == "esperando_aprobacion_script" and response:
                if response == "aprobar_script":
                    video["estado_actual"] = "script_aprobado"
                    self.db.update_video_entry(video["id"], video)
                    self.telegram.send_message(text="✅ Script final aprobado.\n\nIniciando Agente 4 (Descarga de Footage)...")
                    return {
                        "status": "success",
                        "data": {"estado": "script_aprobado", "script_id": video["id"], "siguiente_agente": "agente4_descargador_footage"}
                    }
                else:
                    logger.info(f"Usuario solicitó correcciones: {response}")
                    self.telegram.send_message(text="🔄 Entendido, regenerando el script con tus instrucciones...")
                    extra_instructions = f"EL USUARIO SOLICITÓ LOS SIGUIENTES CAMBIOS: {response}\nReescribe el script aplicando estas instrucciones exactamente."
            elif estado_actual == "generacion_script_pendiente":
                extra_instructions = ""
            else:
                raise ValueError(f"Estado actual '{estado_actual}' no es válido para Agente 3.")
                
            tema = video["tema_seleccionado"]
            keywords = video.get("tema_detalles", {}).get("keywords_auto", [])
            
            logger.info(f"Generando script para: {tema}")
            
            script_text = self._generate_script(tema, keywords, extra_instructions)
            parsed_script = self._parse_script(script_text)
            
            if not parsed_script["parrafos"]:
                raise ValueError("El modelo no generó el formato esperado de párrafos.")
                
            video["script"] = parsed_script
            video["estado_actual"] = "esperando_aprobacion_script"
            self.db.update_video_entry(video["id"], video)
            
            self.telegram.send_message(text=f"📜 <b>SCRIPT GENERADO</b>\n\nTema: {tema}")
            for p in parsed_script['parrafos']:
                self.telegram.send_message(text=f"<b>[{p['numero']}]</b> {p['contenido']}")
                
            msg_status = f"Palabras: {parsed_script['total_palabras']} | Duración est: {parsed_script['total_duracion_formateado']}\n\n👉 <b>¿Aprobado?</b> Haz clic en el botón abajo.\n👉 <b>¿Cambios?</b> Simplemente ESCRIBE lo que quieres cambiar y enviaré a la IA a regenerarlo."
            buttons = [{"label": "✅ Aprobar Script", "value": "aprobar_script"}]
            self.telegram.send_message(text=msg_status, buttons=buttons)
            
            return {
                "status": "success",
                "data": {
                    "script_id": video["id"],
                    "tema": tema,
                    "estado": "esperando_aprobacion_script"
                }
            }
            
        except Exception as e:
            logger.error(f"Error en Agente 3: {e}")
            return {
                "status": "error",
                "message": str(e)
            }

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--telegram-response", type=str, required=False, help="Respuesta del usuario de Telegram")
    args = parser.parse_args()

    with open('config/config.yaml', 'r') as f:
        config = yaml.safe_load(f)
        
    handler = Agente3ScriptHandler(config)
    result = handler.execute(args.telegram_response)
    print(json.dumps(result))
    if result.get("status") == "error":
        sys.exit(1)
