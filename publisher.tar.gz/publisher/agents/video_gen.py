import sys
import os
import json
import asyncio
from datetime import datetime

# Add root to pythonpath
sys.path.append(os.getcwd())

import edge_tts
import whisper
import yaml

from modules.libs.utils import SystemChecker
from modules.publisher.database import Database
from modules.libs.telegram_handler import TelegramHandler
from modules.libs.logger import setup_logger

logger = setup_logger("Agente5")

class Agente5VideoHandler:
    def __init__(self, config):
        self.config = config
        self.db = Database(config['paths']['database'])
        self.telegram = TelegramHandler(
            bot_token=os.getenv("TELEGRAM_BOT_TOKEN"),
            user_id=os.getenv("TELEGRAM_USER_ID")
        )
        
        # Rutas
        self.audio_path = config['paths']['audio']
        self.subs_path = config['paths']['scripts'] # Usando scripts path para subs
        self.rendered_path = config['paths']['rendered']
        
        os.makedirs(self.audio_path, exist_ok=True)
        os.makedirs(self.subs_path, exist_ok=True)
        os.makedirs(self.rendered_path, exist_ok=True)

    async def _generate_audio(self, script_text, video_id):
        logger.info("Generando audio con Edge-TTS...")
        voice = self.config['content']['tts']['voice']
        rate = self.config['content']['tts']['rate']
        output_file = os.path.join(self.audio_path, f"{video_id}_tts.mp3")
        
        try:
            communicate = edge_tts.Communicate(text=script_text, voice=voice, rate=rate)
            await communicate.save(output_file)
            return output_file
        except Exception as e:
            logger.warning(f"Error con Edge-TTS: {e}. Pausando 60s antes de reintentar...")
            try:
                self.telegram.send_message(text=f"⏳ Error en Microsoft TTS. Pausando 60s antes de reintentar...")
            except: pass
            
            await asyncio.sleep(60)
            try:
                communicate = edge_tts.Communicate(text=script_text, voice=voice, rate=rate)
                await communicate.save(output_file)
                return output_file
            except Exception as e2:
                logger.error(f"Fallo definitivo de Edge-TTS: {e2}. Usando gTTS como fallback.")
                try:
                    self.telegram.send_message(text="🔄 Edge-TTS falló definitivamente. Usando gTTS como Fallback...")
                except: pass
                
                import gtts
                tts = gtts.gTTS(text=script_text, lang='es', slow=False)
                tts.save(output_file)
                return output_file

    def _generate_subtitles(self, audio_file, video_id):
        logger.info("Generando subtítulos con Whisper...")
        model_name = self.config['content']['subtitles']['model']
        # Usamos modelo base (o tiny) según config
        model = whisper.load_model(model_name, device="cpu")
        
        result = model.transcribe(audio_file, language="es", verbose=False)
        
        subs_file = os.path.join(self.subs_path, f"{video_id}.srt")
        
        with open(subs_file, 'w', encoding='utf-8') as f:
            for i, segment in enumerate(result['segments'], 1):
                start = self._format_srt_time(segment['start'])
                end = self._format_srt_time(segment['end'])
                text = segment['text'].strip()
                f.write(f"{i}\n{start} --> {end}\n{text}\n\n")
                
        return subs_file

    def _format_srt_time(self, seconds):
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        millis = int((seconds % 1) * 1000)
        return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"

    def _compile_video(self, video_id, footage_data, audio_file, subs_file):
        logger.info("Compilando video con FFmpeg...")
        concat_file = f"temp_concat_{video_id}.txt"
        
        with open(concat_file, 'w') as f:
            for item in footage_data:
                for vid in item['videos']:
                    f.write(f"file '{os.path.abspath(vid['archivo_local'])}'\n")
        
        output_video = os.path.join(self.rendered_path, f"{video_id}_final.mp4")
        
        # FFmpeg command for concatenating, adding audio, and subtitles
        ffmpeg_cmd = f"""
        ffmpeg -y \\
            -f concat -safe 0 -i {concat_file} \\
            -i {audio_file} \\
            -c:v libx264 \\
            -preset fast \\
            -crf 23 \\
            -s 1920x1080 \\
            -r 30 \\
            -c:a aac \\
            -b:a 128k \\
            -af "pan=stereo|c0=c0|c1=c0" \\
            -filter_complex "[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2:black[v];[v]subtitles={subs_file}:force_style='FontSize=24,FontColor=&HFFFFFF&,BorderStyle=3,BorderColor=&H000000&,Spacing=0'[out]" \\
            -map "[out]" \\
            -map 1:a \\
            -shortest \\
            {output_video}
        """
        
        # Ejecutar FFmpeg
        res = os.system(ffmpeg_cmd)
        if res != 0:
            raise Exception("FFmpeg falló al compilar el video.")
            
        # Clean temp
        if os.path.exists(concat_file):
            os.remove(concat_file)
            
        return output_video

    def execute(self):
        try:
            SystemChecker.assert_resources(min_ram_mb=1000, min_disk_gb=2.0)
            
            video = self.db.get_latest_video()
            if not video or video.get("estado_actual") != "footage_descargado":
                raise ValueError("No hay videos listos para compilación.")
                
            self.telegram.send_message(text="🎬 <b>GENERANDO VIDEO FINAL</b>\n\n1. Generando Audio (TTS)...\n2. Transcribiendo Subtítulos...\n3. Renderizando (FFmpeg)...")
            
            # 1. Unir todo el texto del script
            script_full = " ".join([p["contenido"] for p in video["script"]["parrafos"]])
            
            # 2. Generar Audio
            audio_file = asyncio.run(self._generate_audio(script_full, video["id"]))
            
            # 3. Generar Subs
            subs_file = self._generate_subtitles(audio_file, video["id"])
            
            # 4. Compilar Video
            output_video = self._compile_video(video["id"], video["footage"], audio_file, subs_file)
            
            # Update DB
            video["video_final"] = {
                "archivo": output_video,
                "audio": audio_file,
                "subs": subs_file,
                "resolucion": "1080p",
                "tamaño_mb": os.path.getsize(output_video) / (1024*1024)
            }
            video["estado_actual"] = "video_generado"
            self.db.update_video_entry(video["id"], video)
            
            msg = f"✅ <b>VIDEO FINAL COMPLETADO</b>\n\nArchivo: {os.path.basename(output_video)}\nTamaño: {video['video_final']['tamaño_mb']:.1f} MB\n\n(Avanzando a metadatos...)"
            self.telegram.send_message(text=msg)
            
            return {
                "status": "success",
                "data": {
                    "video_id": video["id"],
                    "archivo": output_video,
                    "estado": "completado"
                }
            }
            
        except Exception as e:
            logger.error(f"Error en Agente5: {e}")
            return {
                "status": "error",
                "message": str(e)
            }

if __name__ == "__main__":
    with open('config/config.yaml', 'r') as f:
        config = yaml.safe_load(f)
        
    handler = Agente5VideoHandler(config)
    result = handler.execute()
    print(json.dumps(result))
    import sys
    if result.get("status") == "error":
        sys.exit(1)
