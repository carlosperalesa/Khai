import sys
import os
import json
import argparse
from datetime import datetime

# Add root to pythonpath
sys.path.append(os.getcwd())

import yaml
from dotenv import load_dotenv

from modules.libs.utils import SystemChecker, retry
from modules.publisher.database import Database
from modules.libs.telegram_handler import TelegramHandler
from modules.libs.logger import setup_logger
from modules.llm_manager import LLMManager

logger = setup_logger("Agente1")

class Agente1TendenciasHandler:
    def __init__(self, config):
        self.config = config
        self.db = Database(config['paths']['database'])
        
        load_dotenv()
        
        # Configure Gemini Manager
        self.api_manager = LLMManager(
            config_dir="config",
            data_dir=os.path.join(config.get('paths', {}).get('data', 'data'), "llm")
        )
        
        # Configure Telegram
        self.telegram = TelegramHandler(
            bot_token=os.getenv("TELEGRAM_BOT_TOKEN"),
            user_id=os.getenv("TELEGRAM_USER_ID")
        )

    @retry(max_attempts=3, delay=2)
    def _search_and_synthesize_trends(self, custom_query: str = None):
        """Usa Gemini con Google Search Grounding para buscar las mejores tendencias"""
        prompt = """
        Eres un Productor de YouTube Experto en Tecnología.
        Tienes acceso a internet en tiempo real. Busca en Google, YouTube, Reddit y sitios de noticias las tendencias MÁS EXPLOSIVAS y VIRALES de HOY sobre Inteligencia Artificial y Ciberseguridad.
        
        Instrucciones:
        1. Identifica los 10 temas con mayor potencial de clics y viralidad basándote en la información que encuentres en la web.
        2. Asigna a cada uno un 'rentabilidad_score' del 1.0 al 10.0 basándote en su potencial (sé realista, usa decimales como 9.2, 8.5).
        3. Genera 5-8 palabras clave en español para cada tema (keywords visuales).
        4. Escribe una descripción breve y atractiva.
        5. Todo debe estar en ESPAÑOL.
        """
        
        if custom_query:
            prompt += f"\n\nATENCIÓN: El usuario ha RECHAZADO los temas anteriores y pidió específicamente: '{custom_query}'. Busca en internet exclusivamente sobre lo que pide el usuario e ignora las instrucciones generales de IA/Ciberseguridad."
            
        prompt += """
        Responde ESTRICTAMENTE con un array JSON usando esta estructura exacta para cada tema:
        [
          {
            "nombre": "Título Atractivo del Tema",
            "fuente": "Nombre del sitio de donde sacaste la info (ej. Reddit, YouTube)",
            "rentabilidad_score": 9.2,
            "descripcion_breve": "Descripción corta de por qué es viral...",
            "keywords_auto": ["keyword1", "keyword2"]
          }
        ]
        Solo devuelve el array JSON crudo, sin bloques de código ```json ni explicaciones extra.
        """
        
        logger.info("Llamando a Gemini con Google Search Grounding...")
        try:
            text = self.api_manager.generate_content(prompt, use_web_search=True)
        except Exception as e:
            raise ValueError(f"Gemini API falló: {e}")
            
        # Remove markdown if present
        if text.startswith("```json"):
            text = text[7:-3]
        elif text.startswith("```"):
            text = text[3:-3]
            
        try:
            trends = json.loads(text.strip())
            for i, t in enumerate(trends):
                t["rank"] = i + 1
            return trends
        except json.JSONDecodeError:
            logger.error(f"Error decoding JSON from Gemini: {text}")
            raise ValueError("El modelo no devolvió un JSON válido.")

    def execute(self, telegram_response: str = None):
        try:
            try:
                msg_inicio = "🔎 <b>AGENTE 1 INICIADO</b>\n\nBuscando tendencias en internet con IA..."
                if telegram_response:
                    msg_inicio = f"🔄 <b>BÚSQUEDA PERSONALIZADA</b>\n\nBuscando en la web: '{telegram_response}'..."
                self.telegram.send_message(text=msg_inicio)
            except:
                pass
                
            SystemChecker.assert_resources()
            
            top_trends = self._search_and_synthesize_trends(custom_query=telegram_response)
            
            # Save to DB
            tendency_id = f"tendencias_{datetime.now().strftime('%Y%m%d%H%M%S')}"
            db_data = {
                "id": tendency_id,
                "fecha": datetime.now().isoformat(),
                "temas": top_trends[:10], # asegurar max 10
                "estado": "pendiente_seleccion"
            }
            
            db = self.db.load()
            if "tendencias" not in db:
                db["tendencias"] = []
                
            db["tendencias"].append(db_data)
            self.db.save(db)
            
            # Format Telegram Message
            msg = f"🔍 <b>TENDENCIAS ENCONTRADAS</b>\n\n"
            buttons = []
            
            for t in top_trends[:10]:
                msg += f"{t['rank']}️⃣ <b>{t['nombre']}</b>\n   Fuente: {t.get('fuente', 'Web')} | Score Viral: {t.get('rentabilidad_score', 0)}/10\n\n"
                buttons.append({"label": str(t['rank']), "value": f"tema_{t['rank']}"})
                
            msg += "👉 Haz clic en el número para elegir, o ESCRIBE lo que quieres que busque si no te gusta ninguno."
            
            logger.info("Enviando mensaje a Telegram...")
            self.telegram.send_message(text=msg, buttons=buttons)
            
            return {
                "status": "success",
                "data": db_data
            }
            
        except Exception as e:
            logger.error(f"Error en Agente1: {e}")
            return {
                "status": "error",
                "message": str(e)
            }

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--telegram-response", type=str, required=False, help="Respuesta del usuario de Telegram")
    args = parser.parse_args()

    with open('config/config.yaml', 'r') as f:
        config = yaml.safe_load(f)
        
    handler = Agente1TendenciasHandler(config)
    result = handler.execute(args.telegram_response)
    print(json.dumps(result))
    if result.get("status") == "error":
        sys.exit(1)
