import sys
import os
import json
import requests
import time
from datetime import datetime

# Add root to pythonpath
sys.path.append(os.getcwd())

import requests
import yaml
from dotenv import load_dotenv

from modules.libs.utils import SystemChecker, retry
from modules.publisher.database import Database
from modules.libs.telegram_handler import TelegramHandler
from modules.libs.logger import setup_logger
from modules.llm_manager import LLMManager

logger = setup_logger("Agente4")

class Agente4FootageHandler:
    def __init__(self, config):
        self.config = config
        self.db = Database(config['paths']['database'])
        self.videos_path = config['paths']['videos_footage']
        os.makedirs(self.videos_path, exist_ok=True)
        
        load_dotenv()
        
        self.api_manager = LLMManager(
            config_dir="config",
            data_dir=os.path.join(config.get('paths', {}).get('data', 'data'), "llm")
        )
        
        self.pexels_key = os.getenv("PEXELS_API_KEY")
        if not self.pexels_key:
            logger.warning("PEXELS_API_KEY no configurado. Las descargas fallarán o usarán placeholders.")
            
        self.telegram = TelegramHandler(
            bot_token=os.getenv("TELEGRAM_BOT_TOKEN"),
            user_id=os.getenv("TELEGRAM_USER_ID")
        )
        
        self.cache_path = config['paths']['cache'] + "/pexels_cache.json"
        os.makedirs(config['paths']['cache'], exist_ok=True)
        self.cache = self._load_cache()

    def _load_cache(self):
        if os.path.exists(self.cache_path):
            with open(self.cache_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}

    def _save_cache(self):
        with open(self.cache_path, 'w', encoding='utf-8') as f:
            json.dump(self.cache, f, ensure_ascii=False)

    @retry(max_attempts=3, delay=2)
    def _generate_keywords_batch(self, parrafos, base_keywords):
        prompt = f"Palabras clave base del tema: {', '.join(base_keywords)}\n\n"
        prompt += "Genera 3 palabras clave EN INGLÉS para buscar videos de stock en Pexels para CADA PÁRRAFO.\nDeben ser conceptos visuales abstractos (ej. 'technology', 'data').\n\n"
        
        for i, p in enumerate(parrafos):
            prompt += f"Párrafo {i+1}: {p['contenido'][:300]}...\n\n"
            
        prompt += """Responde SOLO con un array JSON de arrays de strings (uno por párrafo, en el mismo orden).
        Ejemplo:
        [
            ["technology", "digital", "future"],
            ["office", "computer", "typing"]
        ]
        """
        try:
            text = self.api_manager.generate_content(prompt)
        except Exception as e:
            raise ValueError(f"Gemini API falló: {e}")
        
        if text.startswith("```json"): text = text[7:-3]
        elif text.startswith("```"): text = text[3:-3]
            
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return [["technology"]] * len(parrafos) # fallback

    def _translate_to_english(self, text):
        prompt = f"Traduce el siguiente texto al inglés, manteniendo solo los conceptos visuales clave para buscar en un banco de videos (Pexels). Responde SOLO con el término en inglés, nada más:\n\n{text}"
        try:
            return self.api_manager.generate_content(prompt)
        except Exception:
            return text # Fallback: return original si falla

    @retry(max_attempts=3, delay=5)
    def _search_pexels(self, keyword):
        if not self.pexels_key:
            return [] # Mock if no key
            
        if keyword in self.cache:
            logger.info(f"Usando caché para Pexels: '{keyword}'")
            return self.cache[keyword]
            
        url = "https://api.pexels.com/videos/search"
        headers = {"Authorization": self.pexels_key}
        params = {
            "query": keyword,
            "per_page": 10,
            "orientation": "landscape",
            "min_duration": 10,
            "max_duration": 60
        }
        
        response = requests.get(url, headers=headers, params=params, timeout=10)
        
        if response.status_code in [429, 503]:
            logger.warning("Rate limit de Pexels alcanzado.")
            raise Exception("Pexels Rate Limit")
            
        response.raise_for_status()
        data = response.json()
        videos = data.get("videos", [])
        
        self.cache[keyword] = videos
        self._save_cache()
        return videos

    def _select_best_video(self, videos):
        if not videos: return None
        
        scored = []
        for v in videos:
            score = 0
            if 15 <= v["duration"] <= 35: score += 100
            if any(f["height"] >= 1080 for f in v["video_files"]): score += 100
            elif any(f["height"] >= 720 for f in v["video_files"]): score += 50
            scored.append((v, score))
            
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[0][0]

    @retry(max_attempts=3, delay=3)
    def _download_video(self, url, filename):
        logger.info(f"Descargando {filename}...")
        response = requests.get(url, stream=True, timeout=20)
        response.raise_for_status()
        with open(filename, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        return filename

    def execute(self, response: str = None):
        try:
            SystemChecker.assert_resources(min_disk_gb=1.0)
            
            video = self.db.get_latest_video()
            if not video:
                raise ValueError("No hay videos en la BD.")
                
            estado_actual = video.get("estado_actual")
            
            if estado_actual == "script_aprobado":
                video["estado_actual"] = "esperando_validacion_videos"
                video["agente4_state"] = {
                    "current_idx": 0,
                    "blacklist_ids": [],
                    "parrafos_con_videos": [],
                    "videos_descargados": 0
                }
                self.db.update_video_entry(video["id"], video)
                self.telegram.send_message(text="🎬 <b>DESCARGANDO VIDEOS DE FONDO</b>\n\nBuscando videos en Pexels...\n⏳ Esto tardará unos minutos.")
            elif estado_actual != "esperando_validacion_videos":
                raise ValueError(f"Estado actual '{estado_actual}' no es válido para Agente 4.")
                
            state = video["agente4_state"]
            script_data = video["script"]
            parrafos = script_data["parrafos"]
            base_keywords = video.get("tema_detalles", {}).get("keywords_auto", ["technology"])
            
            if "batch_keywords" not in state:
                logger.info("Generando keywords para todos los párrafos en batch...")
                try:
                    state["batch_keywords"] = self._generate_keywords_batch(parrafos, base_keywords)
                except Exception as e:
                    logger.error(f"Error BATCH Gemini: {e}")
                    state["batch_keywords"] = [["technology"]] * len(parrafos)
                self.db.update_video_entry(video["id"], video)
            
            idx = state["current_idx"]
            
            # Si terminamos todos los párrafos
            if idx >= len(parrafos):
                video["footage"] = state["parrafos_con_videos"]
                video["estado_actual"] = "videos_validados"
                self.db.update_video_entry(video["id"], video)
                self.telegram.send_message(text=f"✅ Footage validado.\nVideos obtenidos: {state['videos_descargados']}/{len(parrafos)}\n\nIniciando Agente 5 (Renderizado de Video)...")
                return {
                    "status": "success",
                    "data": {
                        "descarga_id": video["id"],
                        "videos_descargados": state["videos_descargados"],
                        "parrafos_totales": len(parrafos),
                        "estado": "videos_validados",
                        "siguiente_agente": "agente5_generador_video"
                    }
                }
                
            parrafo = parrafos[idx]
            keywords = state["batch_keywords"][idx] if idx < len(state["batch_keywords"]) else ["technology"]
            blacklist_ids = state["blacklist_ids"]
            
            # Evaluar respuesta del usuario si existe
            if response:
                if response == "aceptar_video":
                    self.telegram.send_message(text=f"✅ Video {parrafo['numero']} aceptado.")
                    
                    # Guardar el video actual (está en pending_video)
                    if "pending_video" in state:
                        pv = state.pop("pending_video")
                        state["parrafos_con_videos"].append({
                            "parrafo_numero": parrafo["numero"],
                            "keywords_usados": keywords,
                            "videos": [pv]
                        })
                        state["videos_descargados"] += 1
                        
                    state["current_idx"] += 1
                    state["blacklist_ids"] = []
                    self.db.update_video_entry(video["id"], video)
                    # Recursión para procesar el siguiente párrafo inmediatamente
                    return self.execute()
                    
                elif response == "rechazar_video":
                    self.telegram.send_message(text="🔄 Buscando alternativa...")
                    if "pending_video" in state:
                        blacklist_ids.append(state["pending_video"]["pexels_id"])
                        
                else:
                    self.telegram.send_message(text=f"🔄 Buscando videos sobre: '{response}'...")
                    translated_kw = self._translate_to_english(response)
                    logger.info(f"Texto traducido a: {translated_kw}")
                    state["batch_keywords"][idx] = [translated_kw]
                    if "pending_video" in state:
                        blacklist_ids.append(state["pending_video"]["pexels_id"])
            
            # Descargar y mostrar video para el current_idx
            best_video = None
            for kw in state["batch_keywords"][idx]:
                videos = self._search_pexels(kw)
                videos = [v for v in videos if v["id"] not in blacklist_ids]
                best_video = self._select_best_video(videos)
                if best_video:
                    break
                    
            if not best_video:
                self.telegram.send_message(text=f"⚠️ No hay más opciones para el párrafo {parrafo['numero']}. Usaré un genérico.")
                videos = self._search_pexels("technology")
                videos = [v for v in videos if v["id"] not in blacklist_ids]
                best_video = self._select_best_video(videos)
                
            if best_video:
                v_files = sorted(best_video["video_files"], key=lambda x: x["height"], reverse=True)
                best_file = v_files[0]["link"]
                
                filename = f"{self.videos_path}/{video['id']}_p{parrafo['numero']}.mp4"
                self._download_video(best_file, filename)
                
                # Guardar el pending_video en state
                state["pending_video"] = {
                    "pexels_id": best_video["id"],
                    "url": best_video["url"],
                    "archivo_local": filename,
                    "duracion": best_video["duration"]
                }
                self.db.update_video_entry(video["id"], video)
                
                try:
                    self.telegram.send_video_preview(video_path=filename, caption=f"🎥 <b>Párrafo {parrafo['numero']}</b>\nKeywords: {', '.join(state['batch_keywords'][idx])}")
                except Exception as e:
                    logger.error(f"Error preview telegram: {e}")
                    ip = os.getenv("DROPLET_IP", "164.92.108.20")
                    video_basename = os.path.basename(filename)
                    download_url = f"http://{ip}:8000/videos/{video_basename}"
                    
                    msg_fallback = f"🎥 El video del párrafo {parrafo['numero']} es muy pesado para previsualización.\n\n👉 Míralo aquí:\n{download_url}"
                    self.telegram.send_message(text=msg_fallback)
                    
                buttons = [
                    {"label": "✅ Aceptar", "value": "aceptar_video"},
                    {"label": "❌ Rechazar", "value": "rechazar_video"}
                ]
                self.telegram.send_message(text=f"¿Aprobar video para párrafo {parrafo['numero']}?", buttons=buttons)
                
                return {
                    "status": "success",
                    "data": {
                        "estado": "esperando_validacion_videos",
                        "parrafo": parrafo['numero']
                    }
                }
            else:
                # No se encontró nada, saltar al siguiente
                self.telegram.send_message(text=f"❌ Imposible encontrar video para párrafo {parrafo['numero']}. Saltando.")
                state["current_idx"] += 1
                state["blacklist_ids"] = []
                self.db.update_video_entry(video["id"], video)
                return self.execute()
            
        except Exception as e:
            logger.error(f"Error en Agente 4: {e}")
            return {
                "status": "error",
                "message": str(e)
            }

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--telegram-response", type=str, required=False, help="Respuesta del usuario de Telegram")
    args = parser.parse_args()

    with open('config/config.yaml', 'r') as f:
        config = yaml.safe_load(f)
        
    handler = Agente4FootageHandler(config)
    result = handler.execute(args.telegram_response)
    print(json.dumps(result))
    import sys
    if result.get("status") == "error":
        sys.exit(1)
