import sys
import os
import json
import argparse
from datetime import datetime

# Add root to pythonpath
sys.path.append(os.getcwd())

import yaml
from dotenv import load_dotenv

from modules.libs.utils import SystemChecker
from modules.publisher.database import Database
from modules.libs.telegram_handler import TelegramHandler
from modules.libs.logger import setup_logger

logger = setup_logger("Agente2")

class Agente2SelectorHandler:
    def __init__(self, config):
        self.config = config
        self.db = Database(config['paths']['database'])
        
        load_dotenv()
        
        # Configure Telegram
        self.telegram = TelegramHandler(
            bot_token=os.getenv("TELEGRAM_BOT_TOKEN"),
            user_id=os.getenv("TELEGRAM_USER_ID")
        )

    def execute(self, response: str):
        try:
            SystemChecker.assert_resources()
            
            db_data = self.db.load()
            if "tendencias" not in db_data or not db_data["tendencias"]:
                raise ValueError("No hay tendencias recientes en la BD.")
                
            ultima_tendencia = db_data["tendencias"][-1]
            temas_disponibles = ultima_tendencia.get("temas", [])
            
            tema_seleccionado = None
            tema_obj = None
            
            if response:
                response = response.strip()
                if response.startswith("tema_"):
                    try:
                        rank = int(response.split("_")[1])
                        if 1 <= rank <= len(temas_disponibles):
                            tema_obj = temas_disponibles[rank - 1]
                            tema_seleccionado = tema_obj["nombre"]
                    except (ValueError, IndexError):
                        pass
                elif response.startswith("/personalizado"):
                    tema_seleccionado = response.replace("/personalizado", "").strip()
                    if not tema_seleccionado:
                        tema_seleccionado = "Tema personalizado vacío"
                    tema_obj = {
                        "nombre": tema_seleccionado,
                        "fuente": "usuario",
                        "rentabilidad_score": 10.0,
                        "keywords_auto": ["tecnología", "personalizado"]
                    }
                elif response.isdigit():
                    rank = int(response)
                    if 1 <= rank <= len(temas_disponibles):
                        tema_obj = temas_disponibles[rank - 1]
                        tema_seleccionado = tema_obj["nombre"]
            
            if not tema_seleccionado:
                logger.warning("Respuesta inválida. Seleccionando tema #1 por defecto.")
                if temas_disponibles:
                    tema_obj = temas_disponibles[0]
                    tema_seleccionado = tema_obj["nombre"]
                else:
                    raise ValueError("No hay temas disponibles para seleccionar.")
                    
            video_entry = {
                "fecha": datetime.now().isoformat(),
                "tema_seleccionado": tema_seleccionado,
                "tema_detalles": tema_obj,
                "aprobaciones": {
                    "tema": {
                        "usuario": os.getenv("TELEGRAM_USER_ID"),
                        "timestamp": datetime.now().isoformat()
                    }
                },
                "estado_actual": "generacion_script_pendiente"
            }
            
            video_id = self.db.add_video_entry(video_entry)
            
            db_data = self.db.load()
            ultima_tendencia = db_data["tendencias"][-1]
            ultima_tendencia["estado"] = "tema_seleccionado"
            ultima_tendencia["tema_elegido"] = tema_seleccionado
            self.db.save(db_data)
            
            logger.info(f"Tema registrado: {tema_seleccionado}")
            
            msg = f"✅ <b>Tema seleccionado:</b> \"{tema_seleccionado}\"\nScore: {tema_obj.get('rentabilidad_score', '?')}/10\n\nIniciando generación de script (Agente 3)...\n⏳ Esto tardará ~3-4 minutos."
            self.telegram.send_message(text=msg)
            
            return {
                "status": "success",
                "data": {
                    "tema_seleccionado": tema_seleccionado,
                    "tema_id": video_id,
                    "keywords": tema_obj.get("keywords_auto", []),
                    "rentabilidad_score": tema_obj.get("rentabilidad_score", 0),
                    "usuario": "telegram_user",
                    "timestamp": datetime.now().isoformat(),
                    "siguiente_agente": "agente3_generador_script"
                }
            }
            
        except Exception as e:
            logger.error(f"Error en Agente2: {e}")
            return {
                "status": "error",
                "message": str(e)
            }

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--telegram-response", type=str, required=True, help="Respuesta del usuario de Telegram")
    args = parser.parse_args()

    with open('config/config.yaml', 'r') as f:
        config = yaml.safe_load(f)
        
    handler = Agente2SelectorHandler(config)
    result = handler.execute(args.telegram_response)
    print(json.dumps(result))
    if result.get("status") == "error":
        sys.exit(1)
