import sys
import os
import json
from datetime import datetime, timedelta

# Add root to pythonpath
sys.path.append(os.getcwd())

import yaml
from dotenv import load_dotenv

from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

from modules.libs.utils import SystemChecker, retry
from modules.publisher.database import Database
from modules.libs.telegram_handler import TelegramHandler
from modules.libs.logger import setup_logger

logger = setup_logger("Agente7")

class Agente7YoutubeHandler:
    def __init__(self, config):
        self.config = config
        self.db = Database(config['paths']['database'])
        
        load_dotenv()
        
        self.telegram = TelegramHandler(
            bot_token=os.getenv("TELEGRAM_BOT_TOKEN"),
            user_id=os.getenv("TELEGRAM_USER_ID")
        )
        
        self.test_mode = os.getenv("TEST_MODE", "False").lower() == "true"
        self.token_file = os.getenv("GOOGLE_OAUTH_TOKEN_JSON", "data/certs/token.json")

    def _authenticate(self):
        if not self.token_file or not os.path.exists(self.token_file):
            logger.warning(f"Archivo de token no encontrado ({self.token_file}). Ejecuta scripts/auth_youtube.py primero.")
            if not self.test_mode:
                raise FileNotFoundError(f"Falta el archivo {self.token_file}")
            return None
            
        SCOPES = ['https://www.googleapis.com/auth/youtube.upload']
        credentials = Credentials.from_authorized_user_file(self.token_file, SCOPES)
        return build('youtube', 'v3', credentials=credentials)

    @retry(max_attempts=3, delay=5)
    def _upload_video(self, youtube, video_path, metadata, schedule_time):
        if self.test_mode or not youtube:
            logger.info("TEST_MODE activo: Simulando subida a YouTube.")
            return "dQw4w9WgXcQ" # Mock video ID
            
        body = {
            'snippet': {
                'title': metadata['titulo_elegido'],
                'description': metadata['descripcion'],
                'tags': metadata['tags'],
                'categoryId': self.config['publishing']['category_id'],
                'defaultLanguage': self.config['content']['language'],
                'defaultAudioLanguage': self.config['content']['language']
            },
            'status': {
                'privacyStatus': 'private', # Private initial, scheduled below
                'madeForKids': self.config['publishing']['made_for_kids']
            }
        }
        
        # Schedule if privacy_status is scheduled in config
        if self.config['publishing']['privacy_status'] == 'scheduled':
            body['status']['publishAt'] = schedule_time
        
        media = MediaFileUpload(video_path, mimetype='video/mp4', resumable=True, chunksize=1024*1024*5) # 5MB chunks
        
        request = youtube.videos().insert(
            part='snippet,status',
            body=body,
            media_body=media
        )
        
        response = None
        while response is None:
            status, response = request.next_chunk()
            if status:
                logger.info(f"Subida de video: {int(status.progress() * 100)}%")
                
        return response['id']

    @retry(max_attempts=3, delay=2)
    def _upload_thumbnail(self, youtube, video_id, thumbnail_path):
        if self.test_mode or not youtube or not thumbnail_path or not os.path.exists(thumbnail_path):
            return
            
        request = youtube.thumbnails().set(
            videoId=video_id,
            media_body=MediaFileUpload(thumbnail_path, mimetype='image/jpeg')
        )
        request.execute()
        logger.info("Thumbnail subido exitosamente.")

    def execute(self, response: str = None):
        try:
            SystemChecker.assert_resources()
            
            video = self.db.get_latest_video()
            if not video:
                raise ValueError("No hay videos en la BD.")
                
            estado_actual = video.get("estado_actual")
            
            if estado_actual == "metadatos_aprobados":
                video["estado_actual"] = "esperando_publicacion"
                self.db.update_video_entry(video["id"], video)
                
                video_file = video["video_final"]["archivo"]
                ip = os.getenv("DROPLET_IP", "164.92.108.20")
                video_basename = os.path.basename(video_file)
                download_url = f"http://{ip}:8000/rendered/{video_basename}"
                
                msg_confirm = f"🎬 <b>VIDEO FINAL LISTO PARA YOUTUBE</b>\n\n"
                msg_confirm += f"Título: {video['metadatos']['titulo_elegido']}\n"
                msg_confirm += f"Descarga y revisa el video aquí:\n{download_url}\n\n"
                msg_confirm += "¿Proceder con la subida a YouTube?"
                
                buttons = [
                    {"label": "✅ Subir a YouTube", "value": "subir_youtube"},
                    {"label": "❌ Cancelar Subida", "value": "cancelar_subida"}
                ]
                self.telegram.send_message(text=msg_confirm, buttons=buttons)
                return {
                    "status": "success",
                    "data": {"estado": "esperando_publicacion"}
                }
                
            elif estado_actual == "esperando_publicacion":
                if not response:
                    raise ValueError("Se esperaba una respuesta de Telegram para publicar el video.")
                    
                if response == "cancelar_subida":
                    video["estado_actual"] = "publicacion_cancelada"
                    self.db.update_video_entry(video["id"], video)
                    self.telegram.send_message(text="❌ Subida a YouTube cancelada.")
                    return {"status": "success", "data": {"estado": "publicacion_cancelada"}}
                    
                elif response == "subir_youtube":
                    self.telegram.send_message(text="📤 <b>INICIANDO SUBIDA A YOUTUBE...</b>\n\nEste proceso tomará varios minutos.")
                    youtube = self._authenticate()
                    
                    now = datetime.now()
                    pub_time_str = self.config['publishing']['default_publish_time']
                    h, m = map(int, pub_time_str.split(':'))
                    schedule_date = now.replace(hour=h, minute=m, second=0, microsecond=0)
                    if schedule_date <= now:
                        schedule_date += timedelta(days=1)
                        
                    iso_publish_time = schedule_date.astimezone().isoformat()
                    video_file = video["video_final"]["archivo"]
                    
                    # Upload Video
                    video_id = self._upload_video(youtube, video_file, video["metadatos"], iso_publish_time)
                    
                    # Upload Thumbnail
                    thumb_file = video["metadatos"].get("thumbnail")
                    if thumb_file:
                        self._upload_thumbnail(youtube, video_id, thumb_file)
                        
                    youtube_data = {
                        "video_id": video_id,
                        "url": f"https://www.youtube.com/watch?v={video_id}",
                        "estado": "scheduled" if self.config['publishing']['privacy_status'] == 'scheduled' else "published",
                        "fecha_programada": iso_publish_time,
                        "timestamp_subida": datetime.now().isoformat()
                    }
                    
                    video["youtube"] = youtube_data
                    video["estado_actual"] = "publicado"
                    self.db.update_video_entry(video["id"], video)
                    
                    msg = f"✅ <b>VIDEO SUBIDO EXITOSAMENTE</b>\n\nVideo ID: {video_id}\nTítulo: {video['metadatos']['titulo_elegido']}\nPublicación: {schedule_date.strftime('%Y-%m-%d %H:%M')}\n\n📺 Ver en YouTube:\n{youtube_data['url']}"
                    self.telegram.send_message(text=msg)
                    
                    return {
                        "status": "success",
                        "data": youtube_data
                    }
                else:
                    self.telegram.send_message(text="Respuesta no reconocida. Usa los botones para Aprobar o Cancelar.")
                    return {"status": "success", "data": {"estado": "esperando_publicacion"}}
            else:
                raise ValueError(f"Estado actual '{estado_actual}' no es válido para Agente 7.")
            
        except Exception as e:
            logger.error(f"Error en Agente7: {e}")
            return {
                "status": "error",
                "message": str(e)
            }

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--telegram-response", type=str, required=False, help="Respuesta del usuario de Telegram")
    args = parser.parse_args()

    with open('config/config.yaml', 'r') as f:
        config = yaml.safe_load(f)
        
    handler = Agente7YoutubeHandler(config)
    result = handler.execute(args.telegram_response)
    print(json.dumps(result))
    if result.get("status") == "error":
        sys.exit(1)
