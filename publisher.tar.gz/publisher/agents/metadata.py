import sys
import os
import json
import difflib
import argparse
from datetime import datetime

# Add root to pythonpath
sys.path.append(os.getcwd())

import requests
import yaml
from dotenv import load_dotenv

from modules.libs.utils import SystemChecker, retry
from modules.publisher.database import Database
from modules.libs.telegram_handler import TelegramHandler
from modules.libs.logger import setup_logger
from modules.llm_manager import LLMManager

logger = setup_logger("Agente6")

class Agente6MetadatosHandler:
    def __init__(self, config):
        self.config = config
        self.db = Database(config['paths']['database'])
        self.thumbnails_path = config['paths']['thumbnails']
        os.makedirs(self.thumbnails_path, exist_ok=True)
        
        load_dotenv()
        
        self.api_manager = LLMManager(
            config_dir="config",
            data_dir=os.path.join(config.get('paths', {}).get('data', 'data'), "llm")
        )
        
        self.telegram = TelegramHandler(
            bot_token=os.getenv("TELEGRAM_BOT_TOKEN"),
            user_id=os.getenv("TELEGRAM_USER_ID")
        )

    @retry(max_attempts=3, delay=2)
    def _generate_metadata(self, tema, keywords, duration, extra_instructions=""):
        prompt = f"""
        TAREA: Generar Metadatos SEO para YouTube.
        TEMA: {tema}
        KEYWORDS: {', '.join(keywords)}
        
        Genera:
        1. 3 opciones de Títulos atractivos (max 60 caracteres)
        2. Descripción de 2 párrafos
        3. 20 Tags (separados por coma)
        
        {extra_instructions}
        
        Responde SOLO con un JSON válido usando estas llaves exactas: "titulos" (array de strings), "descripcion" (string), "tags" (array de strings).
        """
        try:
            text = self.api_manager.generate_content(prompt)
        except Exception as e:
            raise ValueError(f"Gemini API falló: {e}")
        
        if text.startswith("```json"): text = text[7:-3]
        elif text.startswith("```"): text = text[3:-3]
            
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            logger.error("Error parseando JSON de Gemini. Usando fallback.")
            return {
                "titulos": [f"{tema}: Lo que debes saber en 2025", f"Guía completa sobre {tema}", f"El futuro de {tema}"],
                "descripcion": f"En este video te explicamos todo sobre {tema}. ¡No olvides suscribirte!",
                "tags": keywords + ["tecnologia", "youtube", "2025", "tendencias"]
            }

    def _check_duplicates(self, titulo_propuesto):
        db_data = self.db.load()
        for video in db_data.get('videos', []):
            titulo_anterior = video.get('metadatos', {}).get('titulo_elegido', '')
            if not titulo_anterior: continue
            
            sim = difflib.SequenceMatcher(None, titulo_propuesto.lower(), titulo_anterior.lower()).ratio()
            if sim > 0.8:
                return False
        return True

    def _extract_thumbnail(self, video_path, titulo, video_id):
        logger.info("Generando thumbnail...")
        thumb_temp = os.path.join(self.thumbnails_path, f"temp_{video_id}.jpg")
        thumb_final = os.path.join(self.thumbnails_path, f"thumb_{video_id}.jpg")
        
        # Extract frame at 10 seconds
        os.system(f"ffmpeg -y -i {video_path} -ss 10 -vframes 1 -s 1280x720 {thumb_temp} > /dev/null 2>&1")
        
        if not os.path.exists(thumb_temp):
            logger.warning("Fallo al extraer frame, no se generará texto en thumbnail.")
            return None
            
        try:
            from PIL import Image, ImageDraw, ImageFont
            img = Image.open(thumb_temp)
            draw = ImageDraw.Draw(img)
            
            font = ImageFont.load_default()
            
            x, y = 50, 600
            draw.rectangle([(x-10, y-10), (x+800, y+30)], fill=(0, 0, 0))
            draw.text((x, y), titulo[:50], fill=(255, 255, 255), font=font)
            
            img.save(thumb_final)
            os.remove(thumb_temp)
            return thumb_final
        except Exception as e:
            logger.warning(f"Error añadiendo texto a thumbnail con Pillow: {e}")
            os.rename(thumb_temp, thumb_final)
            return thumb_final

    def execute(self, response: str = None):
        try:
            SystemChecker.assert_resources()
            
            video = self.db.get_latest_video()
            if not video:
                raise ValueError("No hay videos en la BD.")
                
            estado_actual = video.get("estado_actual")
            tema = video["tema_seleccionado"]
            keywords = video.get("tema_detalles", {}).get("keywords_auto", [])
            
            if estado_actual == "esperando_seleccion_titulo" and response:
                if response == "aprobar_metadatos":
                    video["estado_actual"] = "metadatos_aprobados"
                    self.db.update_video_entry(video["id"], video)
                    self.telegram.send_message(text="✅ Metadatos aprobados. Iniciando Agente 7 (Publicador YouTube)...")
                    return {
                        "status": "success",
                        "data": {"estado": "metadatos_aprobados", "siguiente_agente": "agente7_publicador_youtube"}
                    }
                elif response.startswith("titulo_"):
                    try:
                        idx = int(response.split("_")[1]) - 1
                        titulo_elegido = video["metadatos"]["opciones_titulo"][idx]
                        video["metadatos"]["titulo_elegido"] = titulo_elegido
                        video["estado_actual"] = "metadatos_aprobados"
                        
                        # Regenerar thumbnail con nuevo titulo
                        video_file = video["video_final"]["archivo"]
                        thumb_file = self._extract_thumbnail(video_file, titulo_elegido, video["id"])
                        video["metadatos"]["thumbnail"] = thumb_file
                        
                        self.db.update_video_entry(video["id"], video)
                        self.telegram.send_message(text=f"✅ Título elegido: {titulo_elegido}\nIniciando Agente 7...")
                        return {
                            "status": "success",
                            "data": {"estado": "metadatos_aprobados", "siguiente_agente": "agente7_publicador_youtube"}
                        }
                    except (ValueError, IndexError):
                        pass
                
                # Conversational text feedback
                logger.info(f"Usuario solicitó correcciones en metadatos: {response}")
                self.telegram.send_message(text="🔄 Regenerando opciones de título/descripción según tus instrucciones...")
                extra_instructions = f"EL USUARIO RECHAZÓ LAS OPCIONES Y PIDIÓ ESTO: {response}\nGenera nuevas opciones aplicando estrictamente estos cambios."
            
            elif estado_actual == "video_generado":
                extra_instructions = ""
            else:
                raise ValueError(f"Estado actual '{estado_actual}' no es válido para Agente 6.")
                
            logger.info("Generando metadatos SEO...")
            meta = self._generate_metadata(tema, keywords, 10, extra_instructions)
            
            titulo_elegido = meta["titulos"][0]
            
            if "metadatos" not in video:
                video_file = video["video_final"]["archivo"]
                thumb_file = self._extract_thumbnail(video_file, titulo_elegido, video["id"])
                video["metadatos"] = {}
                video["metadatos"]["thumbnail"] = thumb_file
                
            video["metadatos"]["titulo_elegido"] = titulo_elegido
            video["metadatos"]["opciones_titulo"] = meta["titulos"]
            video["metadatos"]["descripcion"] = meta["descripcion"]
            video["metadatos"]["tags"] = meta["tags"]
            video["metadatos"]["seo_score"] = 8.5
            
            video["estado_actual"] = "esperando_seleccion_titulo"
            self.db.update_video_entry(video["id"], video)
            
            msg = f"📝 <b>METADATOS GENERADOS</b>\n\nElige un título:\n"
            buttons = []
            for i, t in enumerate(meta["titulos"]):
                msg += f"{i+1}️⃣ {t}\n\n"
                buttons.append({"label": f"Título {i+1}", "value": f"titulo_{i+1}"})
                
            msg += "👉 <b>Haz clic</b> en el título que prefieras.\n👉 O <b>ESCRIBE</b> tus instrucciones (ej: 'Haz los títulos más llamativos' o 'Usa el título: Mi Título Perfecto')."
            
            self.telegram.send_message(text=msg, buttons=buttons)
            
            return {
                "status": "success",
                "data": {
                    "metadatos_id": video["id"],
                    "estado": "esperando_seleccion_titulo"
                }
            }
            
        except Exception as e:
            logger.error(f"Error en Agente6: {e}")
            return {
                "status": "error",
                "message": str(e)
            }

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--telegram-response", type=str, required=False, help="Respuesta del usuario de Telegram")
    args = parser.parse_args()

    with open('config/config.yaml', 'r') as f:
        config = yaml.safe_load(f)
        
    handler = Agente6MetadatosHandler(config)
    result = handler.execute(args.telegram_response)
    print(json.dumps(result))
    if result.get("status") == "error":
        sys.exit(1)
