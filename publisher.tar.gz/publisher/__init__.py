import logging
import subprocess

from .database import Database

logger = logging.getLogger("PublisherPipeline")

class PublisherPipeline:
    """Pipeline completo de generación y publicación de video."""

    def __init__(self, llm, telegram, data_dir: str):
        import os
        self.db = Database(os.path.join(data_dir, "database.json"))
        self.llm = llm
        self.telegram = telegram
        self.data_dir = data_dir

    def evaluate_state(self, telegram_response: str = None) -> None:
        """Máquina de estados (extraída de orchestrator.py)."""
        logger.info(f"Evaluando máquina de estados con input: {telegram_response}")
        
        video = self.db.get_latest_video()
        
        if not video:
            db_data = self.db.load()
            if "tendencias" in db_data and db_data["tendencias"]:
                ultima_tendencia = db_data["tendencias"][-1]
                if ultima_tendencia.get("estado") == "pendiente_seleccion" and telegram_response:
                    response_clean = telegram_response.strip().lower()
                    if response_clean.isdigit() or response_clean.startswith("tema_") or response_clean.startswith("/personalizado"):
                        self.run_agent("selector", telegram_response)
                        self.evaluate_state() 
                    else:
                        self.run_agent("detector", telegram_response)
            return

        estado = video.get("estado_actual")
        
        if estado == "generacion_script_pendiente":
            self.run_agent("script_gen")
            
        elif estado == "esperando_aprobacion_script" and telegram_response:
            self.run_agent("script_gen", telegram_response)
            self.evaluate_state()
            
        elif estado == "script_aprobado":
            self.run_agent("footage")
            
        elif estado == "esperando_validacion_videos" and telegram_response:
            self.run_agent("footage", telegram_response)
            self.evaluate_state()
            
        elif estado == "videos_validados":
            self.run_agent("video_gen")
            self.evaluate_state()
            
        elif estado == "video_generado":
            self.run_agent("metadata")
            self.evaluate_state()
            
        elif estado == "esperando_seleccion_titulo" and telegram_response:
            self.run_agent("metadata", telegram_response)
            self.evaluate_state()
            
        elif estado == "metadatos_aprobados":
            self.run_agent("uploader")
            
        elif estado == "esperando_publicacion" and telegram_response:
            self.run_agent("uploader", telegram_response)
            
        else:
            logger.info(f"Estado '{estado}' no requiere acción inmediata.")

    def trigger_daily_trends(self) -> None:
        """Inicia el ciclo diario (Agente 1)."""
        logger.info("Iniciando tarea diaria: Agente 1 (Detector de Tendencias)")
        self.run_agent("detector")

    def run_agent(self, agent_name: str, response: str = None) -> str:
        """Ejecuta un agente específico."""
        cmd = ["python", "-m", f"modules.publisher.agents.{agent_name}"]
        if response:
            cmd.extend(["--telegram-response", response])
        
        logger.info(f"Ejecutando agente {agent_name}...")
        try:
            result = subprocess.run(cmd, check=True, capture_output=True, text=True)
            logger.info(f"Agente {agent_name} completado.")
            return result.stdout
        except subprocess.CalledProcessError as e:
            logger.error(f"Error en {agent_name}: {e.stderr}")
            return None
