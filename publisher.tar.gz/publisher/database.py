import json
import os
import threading
from datetime import datetime
from typing import Dict, List, Optional

class Database:
    """Manejador de BD JSON thread-safe simple."""
    
    _lock = threading.Lock()
    
    def __init__(self, db_path: str = "data/database.json"):
        self.db_path = db_path
        
    def ensure_exists(self):
        """Crear BD si no existe"""
        with self._lock:
            if not os.path.exists(self.db_path):
                # Ensure directory exists
                os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
                initial_db = {
                    "videos": [],
                    "metadata": {
                        "version": "1.0",
                        "created": datetime.now().isoformat()
                    }
                }
                with open(self.db_path, 'w', encoding='utf-8') as f:
                    json.dump(initial_db, f, indent=2, ensure_ascii=False)
    
    def load(self) -> Dict:
        """Cargar BD completa"""
        with self._lock:
            if not os.path.exists(self.db_path):
                return {"videos": []}
            with open(self.db_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    
    def save(self, data: Dict):
        """Guardar BD completa"""
        with self._lock:
            # Atomic save: write to temp file then rename
            temp_path = self.db_path + '.tmp'
            with open(temp_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            os.replace(temp_path, self.db_path)
    
    def add_video_entry(self, video_data: Dict) -> str:
        """Agregar nueva entrada de video"""
        db = self.load()
        
        if 'id' not in video_data:
            video_id = f"video_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            video_data['id'] = video_id
        
        db['videos'].append(video_data)
        self.save(db)
        return video_data['id']
    
    def update_video_entry(self, video_id: str, updates: Dict):
        """Actualizar entrada existente"""
        db = self.load()
        
        for video in db['videos']:
            if video['id'] == video_id:
                video.update(updates)
                break
        
        self.save(db)
    
    def get_latest_video(self) -> Optional[Dict]:
        """Obtener último video"""
        db = self.load()
        if db.get('videos'):
            return db['videos'][-1]
        return None
    
    def get_video_by_id(self, video_id: str) -> Optional[Dict]:
        """Obtener video específico"""
        db = self.load()
        for video in db.get('videos', []):
            if video['id'] == video_id:
                return video
        return None
